const mysql = require("mysql2");
const nodemailer = require("nodemailer");


module.exports.connection = mysql.createConnection({
    host: "db4free.net",
    user: "user_376",
    database: "db_376",
    password: "somebody376"
}).promise();


module.exports.transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: {
        user: "щось_там_щось_там@gmail.com",
        pass: "пароль тобі знати не потрібно"
    },
    tls: {
        rejectUnauthorized: false
    }
});